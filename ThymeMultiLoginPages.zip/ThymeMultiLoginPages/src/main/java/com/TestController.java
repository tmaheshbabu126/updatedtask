package com;

import java.security.Principal;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping
public class TestController {

	@RequestMapping("/")
	public ModelAndView defaultHome() {
		return new ModelAndView("login");
	}

	@RequestMapping("/login")
	public ModelAndView login() {
		return new ModelAndView("login");
	}

	@RequestMapping("/dashboard")
	public ModelAndView userDashboard() {
		return new ModelAndView("dashboard");
	}
	@RequestMapping("/searchResult")
	public ModelAndView searchResult() {
		return new ModelAndView("SearchResult");
	}

	@RequestMapping("/accessdenied")
	public ModelAndView userAccessError() {
		return new ModelAndView("accessdenied");
	}
	
	@RequestMapping("/admin/")
	public ModelAndView admin() {
		return new ModelAndView("admin/login");
	}

	@RequestMapping("/admin/login")
	public ModelAndView adminlogin() {
		return new ModelAndView("admin/login");
	}

	@RequestMapping("/admin/dashboard")
	public ModelAndView admindashboard() {
		return new ModelAndView("admin/dashboard");
	}

	@RequestMapping("/admin/accessdenied")
	public ModelAndView adminAccessError() {
		return new ModelAndView("admin/accessdenied");
	}
	
	@RequestMapping("/user/product-landing-page")
	public ModelAndView productLandingPage(Principal principal,Model model) {
		
		 Object principal1 = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		  String username="";
		    if (principal1 instanceof UserDetails) {
		       username = ((UserDetails)principal1).getUsername();
		    } else {
		       username = principal1.toString();
		    }
		    model.addAttribute("uName", username);
		    System.out.println(username);
		    
		return new ModelAndView("/user");
	}
	
	@RequestMapping("/admin/product-landing-page")
	public ModelAndView productLandingPage1(Principal principal,Model model) {
		  Object principal1 = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		  String username="";
		    if (principal1 instanceof UserDetails) {
		       username = ((UserDetails)principal1).getUsername();
		    } else {
		       username = principal1.toString();
		    }
		    model.addAttribute("uName", username);
		    System.out.println(username);
		return new ModelAndView("/admin/admin");
	}
	
}
