package com;

import java.io.File;
import java.security.Principal;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping
public class TestController {

	@RequestMapping("/")
	public ModelAndView defaultHome() {
		return new ModelAndView("login");
	}

	@RequestMapping("/login")
	public ModelAndView login() {
		return new ModelAndView("login");
	}

	@RequestMapping("/dashboard")
	public ModelAndView userDashboard() {
		return new ModelAndView("dashboard");
	}
	@RequestMapping("/searchResult")
	public ModelAndView searchResult() {
		return new ModelAndView("SearchResult");
	}

	@RequestMapping("/accessdenied")
	public ModelAndView userAccessError() {
		return new ModelAndView("accessdenied");
	}
	
	@RequestMapping("/admin/")
	public ModelAndView admin() {
		return new ModelAndView("admin/login");
	}

	@RequestMapping("/admin/login")
	public ModelAndView adminlogin() {
		return new ModelAndView("admin/login");
	}

	@RequestMapping("/admin/dashboard")
	public ModelAndView admindashboard() {
		return new ModelAndView("admin/dashboard");
	}

	@RequestMapping("/admin/accessdenied")
	public ModelAndView adminAccessError() {
		return new ModelAndView("admin/accessdenied");
	}
	
	@RequestMapping("/user/product-landing-page")
	public ModelAndView productLandingPage(Principal principal,Model model) {
		
		 Object principal1 = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		  String username="";
		    if (principal1 instanceof UserDetails) {
		       username = ((UserDetails)principal1).getUsername();
		    } else {
		       username = principal1.toString();
		    }
		    model.addAttribute("uName", username);
		    System.out.println(username);
		    
		return new ModelAndView("/user");
	}
	
	@RequestMapping("/admin/product-landing-page")
	public ModelAndView productLandingPage1(Principal principal,Model model) {
		  Object principal1 = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		  String username="";
		    if (principal1 instanceof UserDetails) {
		       username = ((UserDetails)principal1).getUsername();
		    } else {
		       username = principal1.toString();
		    }
		    model.addAttribute("uName", username);
		    System.out.println(username);
		    
		    // --------------adding the enable access if there are files in upload folder
			File dir = new File("C:\\Users\\mahes\\Desktop\\Task-CG-Asha\\Files\\Input File");
		    String[] children = dir.list();
		    boolean enableAccess;
		    
		    if (children.length==0) {
		       System.out.println("files are not available in the folder so buttons need to be disabled");
		       enableAccess = false;
		    } else {
		  	  System.out.println("in file parsing, files are available in folder so enable");
		       for (int i = 0; i < children.length; i++) {
		          String filename = children[i];
		          System.out.println(filename);
		       }
		       enableAccess = true;
		        
		    }
		    
		    model.addAttribute("enableAccess", enableAccess);
			
			System.out.println("the button access need to be enabled = "+enableAccess);
			
			
			
		    
		return new ModelAndView("/admin/admin");
	}
	
}
