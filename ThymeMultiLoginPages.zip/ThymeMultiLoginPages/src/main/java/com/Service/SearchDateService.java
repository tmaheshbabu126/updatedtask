package com.Service;

import org.springframework.stereotype.Service;

import com.Entity.SearchDate;

@Service
public interface SearchDateService {
	public void addDate(SearchDate searchDate);

}
