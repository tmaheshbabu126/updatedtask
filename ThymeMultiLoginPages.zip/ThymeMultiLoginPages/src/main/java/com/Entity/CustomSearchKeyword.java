package com.Entity;

public class CustomSearchKeyword  {
	
	
	private SearchKeyWords searchKeyWords;

	public CustomSearchKeyword(SearchKeyWords searchKeyWords) {
		super();
		this.setSearchKeyWords(searchKeyWords);
	}

	public SearchKeyWords getSearchKeyWords() {
		return searchKeyWords;
	}

	public void setSearchKeyWords(SearchKeyWords searchKeyWords) {
		this.searchKeyWords = searchKeyWords;
	}
	
	

}
